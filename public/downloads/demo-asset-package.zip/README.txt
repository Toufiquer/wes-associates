Demo asset package
This is a placeholder download generated for the demo checkout flow.
Replace this ZIP with the real purchased asset later.
